#include"Broo_Func.h"

int main(){
	Play_Game();
	gotoxy(0, 41);
	printf("\n");
	getch();
}