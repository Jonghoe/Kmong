extern void Swap(int [], int, int);
extern void BubbleSort(int list[], int n);
extern void InsertionSort(int list[], int n);
extern void SelectSort(int list[], int n);
extern void QuickSort(int list[], int n);
extern void MergeSort(int list[], int n);
extern void HeapSort(int list[], int n);
extern void RadixSort(int list[], int n);
